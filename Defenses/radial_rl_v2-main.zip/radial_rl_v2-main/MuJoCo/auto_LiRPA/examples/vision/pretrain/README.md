Very small pretrained models for illustration only.
