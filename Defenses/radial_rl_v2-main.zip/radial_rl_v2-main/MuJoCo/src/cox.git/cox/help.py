help_str = """
Available scripts:
- make-experiments (for grid search)
- archive (upload as experiment to deep-gpu-monitor)
- tensorboard-view (nice viewer for grids in tensorboard)
- verify-experiments (make sure all experiments worked ok/debugging)
- help (this script)
- from-study (import study to cox format)
"""
print(help_str)
