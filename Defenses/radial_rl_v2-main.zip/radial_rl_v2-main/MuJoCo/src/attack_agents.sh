#!/bin/bash


python run.py --config-path config_invertpendulum_robust_ppo_convex.json
